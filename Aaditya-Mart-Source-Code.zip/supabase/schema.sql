-- Aaditya Mart starter schema
-- Run in Supabase SQL Editor. Review policies before production launch.
create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text not null,
  description text default '',
  price numeric(10,2) not null check (price >= 0),
  stock integer not null default 0 check (stock >= 0),
  emoji text default '🛍️',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.customers (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references auth.users(id),
  total_amount numeric(10,2) not null check (total_amount >= 0),
  status text not null default 'pending' check (status in ('pending','paid','processing','shipped','delivered','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  quantity integer not null check (quantity > 0),
  unit_price numeric(10,2) not null check (unit_price >= 0)
);

alter table public.products enable row level security;
alter table public.customers enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;

-- Public users may only read active products. No public writes are granted.
drop policy if exists "Anyone can read active products" on public.products;
create policy "Anyone can read active products" on public.products
for select using (is_active = true);

-- Customers may read and update only their own profile.
drop policy if exists "Customers read own profile" on public.customers;
create policy "Customers read own profile" on public.customers
for select to authenticated using (auth.uid() = id);
drop policy if exists "Customers update own profile" on public.customers;
create policy "Customers update own profile" on public.customers
for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- Customers may read their own orders and items.
drop policy if exists "Customers read own orders" on public.orders;
create policy "Customers read own orders" on public.orders
for select to authenticated using (auth.uid() = customer_id);
drop policy if exists "Customers read own order items" on public.order_items;
create policy "Customers read own order items" on public.order_items
for select to authenticated using (
  exists (select 1 from public.orders o where o.id = order_id and o.customer_id = auth.uid())
);

-- IMPORTANT:
-- This starter intentionally does not grant client-side order creation or product writes.
-- Add secure Edge Functions/RPC with server-side validation for checkout, inventory decrement,
-- admin product management, price verification, and role checks before production use.
